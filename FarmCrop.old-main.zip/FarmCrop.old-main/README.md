# FarmCrop

A responsive React + TypeScript frontend for a farmer-to-customer agricultural marketplace.

## Run locally

```bash
npm install
npm run dev
```

Build for production with `npm run build`, then preview with `npm run preview`.

## Routes

- `/` - FarmCrop homepage
- `/marketplace` - searchable and filterable crop marketplace
- `/farmers` - farmer onboarding surface

## Frontend boundaries

All crop prices, demand insights, community statistics, images, and Krishi Saathi responses are demo data. Cart state is frontend-only and payment is not connected. No individual farmer financial data or leaderboard is displayed.

## Backend setup

Authentication, profile persistence, crop listings, inventory, orders, payments, and Seller approval will be provided by the future Spring Boot + MySQL backend. The frontend currently does not connect to an authentication or database backend, so login and phone verification remain unavailable rather than simulating success.

Set `VITE_API_BASE_URL` when a compatible Spring Boot API is available. No backend endpoints are assumed by the current frontend.

Mock data lives in `src/data.ts`; replace it with API service calls when the backend is ready. The first backend boundary should provide crop listings, availability, locations, and cart/order persistence without exposing private farmer financial data.
